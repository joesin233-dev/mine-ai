// Stage 1 placeholder — final Report screen.
export default function ReportPage({ params }: { params: { analysisId: string } }) {
  return (
    <main style={{ padding: 24, maxWidth: 480, margin: "0 auto" }}>
      <h1>Report</h1>
      <p>Analysis: {params.analysisId}</p>
      <p style={{ color: "#666" }}>Report engine not built yet (Stage 10).</p>
    </main>
  );
}
